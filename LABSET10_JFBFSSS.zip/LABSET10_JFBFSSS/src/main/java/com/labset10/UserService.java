package com.labset10;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class UserService {

	static Map<Integer, User> maps = new HashMap<Integer, User>();

	public List<User> fetchUsers(Map<Integer, User> maps) {

		List<User> userlist = new ArrayList<User>();

		for (Map.Entry<Integer, User> entry : maps.entrySet()) {

			User out = (User) entry.getValue();

			userlist.add(out.getId(), out);

		}

		return userlist;

	}

	public List<User> listAllUser() {

		return fetchUsers(maps);

	}

	public User getUser(int id) {

		return (User) maps.get(id);

	}

	public void saveUser(User user) {

		maps.put(user.getId(), user);

	}

	public void deleteUser(int id) {

		maps.remove(id);

	}
}
